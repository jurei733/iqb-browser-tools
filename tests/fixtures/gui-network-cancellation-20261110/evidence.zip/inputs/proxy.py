# Isolated synthetic fault injector for the already authorized local Testcenter.
# No credentials, tokens, request/response bodies or personal data are logged.
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import http.client,json,time,re
root=Path(__file__).parent
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_OPTIONS(self):self.send_response(204);self.end_headers()
 def do_GET(self):self.forward()
 def do_PUT(self):self.forward()
 def do_POST(self):self.forward()
 def do_DELETE(self):self.forward()
 def forward(self):
  if self.client_address[0] not in ['192.168.64.2','192.168.64.1','127.0.0.1']:self.send_error(403);return
  control=json.loads((root/'control.json').read_text());mode=control.get('mode','pass');status=None;body=b''
  if mode=='login401' and '/session' in self.path:status=401
  elif mode=='groups500' and self.path.endswith('/results'):status=500
  elif mode=='token401' and '/workspace/' in self.path:status=401
  elif mode=='report500' and '/report/response' in self.path:status=500
  elif mode=='partial503' and '/report/response' in self.path and 'BROWSER_B' in self.path:status=503
  elif mode=='malformed' and '/report/response' in self.path:status=200;body=b'{malformed'
  elif mode=='empty' and '/report/' in self.path:status=200
  elif mode=='slow' and '/report/response' in self.path or mode=='slowcontent' and '/file/' in self.path:
   (root/'waiting.json').write_text(json.dumps({'waiting':True,'path':self.path}))
   for i in range(2200):
    if json.loads((root/'control.json').read_text()).get('mode')!=mode:break
    time.sleep(.1)
  request_body=self.rfile.read(int(self.headers.get('Content-Length','0')))
  if status is None:
   connection=http.client.HTTPConnection('127.0.0.1',5188,timeout=240)
   headers={k:v for k,v in self.headers.items() if k.lower() not in ['host','content-length','connection','accept-encoding']}
   try:
    connection.request(self.command,self.path,body=request_body,headers=headers);response=connection.getresponse();status=response.status;body=response.read();content_type=response.getheader('Content-Type','application/json')
   except Exception:status=502;body=b'';content_type='application/json'
   finally:connection.close()
  else:content_type='application/json'
  with (root/'events.jsonl').open('a') as f:f.write(json.dumps({'method':self.command,'path':self.path.split('?')[0],'mode':mode,'status':status})+'\n')
  try:self.send_response(status);self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
  except (BrokenPipeError,ConnectionResetError):pass
ThreadingHTTPServer(('192.168.64.1',5201),Handler).serve_forever()
